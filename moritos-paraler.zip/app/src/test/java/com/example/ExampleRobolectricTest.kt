package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.data.CloneRepository
import com.example.engine.VirtualSandboxManager
import com.example.model.AppCategory
import com.example.model.CloneAppType
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class ExampleRobolectricTest {

  @Test
  fun `read app name from context`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val appName = context.getString(R.string.app_name)
    assertEquals("Moritos", appName)
  }

  @Test
  fun `verify virtual sandbox creates isolated directories`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val sandboxManager = VirtualSandboxManager(context)
    val cloneId = "test_clone_whatsapp_2"
    val pkg = "com.whatsapp"

    val dir = sandboxManager.initializeVirtualSpace(cloneId, pkg)
    assertTrue(dir.exists())
    assertTrue(sandboxManager.getVirtualSpaceDir(cloneId).exists())

    val cleared = sandboxManager.clearVirtualCache(cloneId)
    assertTrue(cleared)

    val deleted = sandboxManager.deleteVirtualSpace(cloneId)
    assertTrue(deleted)
  }

  @Test
  fun `verify clone repository adds and persists clones`() = runBlocking {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val sandboxManager = VirtualSandboxManager(context)
    val repository = CloneRepository(context, sandboxManager)

    val initialClones = repository.clonedAppsFlow.value
    assertNotNull(initialClones)

    val newClone = repository.addClone(
      packageName = "com.test.app",
      displayName = "Test App",
      appType = CloneAppType.NATIVE_APP,
      category = AppCategory.TOOLS
    )

    assertEquals("com.test.app", newClone.originalPackageName)
    assertEquals(2, newClone.instanceNumber)

    // Clean up
    repository.removeClone(newClone.id)
  }
}
