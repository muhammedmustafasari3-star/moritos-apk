package com.example

import android.content.Context
import android.content.res.Configuration
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection
import com.example.model.AppThemeMode
import com.example.model.ClonedApp
import com.example.ui.components.PinLockDialog
import com.example.ui.screens.AddAppScreen
import com.example.ui.screens.ArchitectureScreen
import com.example.ui.screens.ContainerRunnerScreen
import com.example.ui.screens.HomeScreen
import com.example.ui.screens.ManageCloneScreen
import com.example.ui.screens.SettingsScreen
import com.example.ui.theme.MoritosTheme
import com.example.viewmodel.MoritosViewModel
import java.util.Locale

enum class ScreenState {
    HOME,
    ADD_APP,
    MANAGE_CLONE,
    ARCHITECTURE,
    SETTINGS,
    CONTAINER_RUNNER
}

class MainActivity : ComponentActivity() {

    private val viewModel: MoritosViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        // Check if launched via home screen shortcut
        val shortcutCloneId = intent?.getStringExtra("LAUNCH_CLONE_ID")
        if (!shortcutCloneId.isNullOrEmpty()) {
            viewModel.selectClone(shortcutCloneId)
        }

        setContent {
            val settings by viewModel.settings.collectAsState()
            val isDarkTheme = when (settings.themeMode) {
                AppThemeMode.SYSTEM -> isSystemInDarkTheme()
                AppThemeMode.DARK -> true
                AppThemeMode.LIGHT -> false
            }

            // Create localized context for dynamic in-app language switching
            val baseContext = LocalContext.current
            val localizedContext = remember(settings.languageCode, baseContext) {
                val locale = Locale(settings.languageCode)
                Locale.setDefault(locale)
                val config = Configuration(baseContext.resources.configuration).apply {
                    setLocale(locale)
                    setLayoutDirection(locale)
                }
                baseContext.createConfigurationContext(config)
            }

            val layoutDirection = if (settings.languageCode == "ar") {
                LayoutDirection.Rtl
            } else {
                LayoutDirection.Ltr
            }

            CompositionLocalProvider(
                LocalContext provides localizedContext,
                LocalLayoutDirection provides layoutDirection
            ) {
                MoritosTheme(darkTheme = isDarkTheme) {
                    MoritosMainApp(
                        viewModel = viewModel,
                        initialShortcutCloneId = shortcutCloneId
                    )
                }
            }
        }
    }
}

@Composable
fun MoritosMainApp(
    viewModel: MoritosViewModel,
    initialShortcutCloneId: String? = null
) {
    val context = LocalContext.current
    val settings by viewModel.settings.collectAsState()
    val clones by viewModel.clonedApps.collectAsState()
    val isPinUnlocked by viewModel.isPinUnlocked.collectAsState()

    var currentScreen by remember { mutableStateOf(ScreenState.HOME) }
    var selectedManageCloneId by remember { mutableStateOf<String?>(null) }
    var containerClone by remember { mutableStateOf<ClonedApp?>(null) }
    var showAppLockPrompt by remember { mutableStateOf(settings.appLockEnabled && !isPinUnlocked) }

    val snackbarHostState = remember { SnackbarHostState() }

    // Handle toast events from ViewModel
    LaunchedEffect(Unit) {
        viewModel.toastEvent.collect { message ->
            Toast.makeText(context, message, Toast.LENGTH_SHORT).show()
        }
    }

    // Handle initial shortcut launch
    LaunchedEffect(initialShortcutCloneId, clones) {
        if (!initialShortcutCloneId.isNullOrEmpty()) {
            val targetClone = clones.find { it.id == initialShortcutCloneId }
            if (targetClone != null) {
                viewModel.launchClone(targetClone) {
                    containerClone = targetClone
                    currentScreen = ScreenState.CONTAINER_RUNNER
                }
            }
        }
    }

    // AppLock Master PIN Gate
    if (showAppLockPrompt && settings.appLockEnabled && !isPinUnlocked) {
        PinLockDialog(
            title = "Moritos AppLock",
            subtitle = "Please enter your master PIN to access Moritos",
            onPinEntered = { enteredPin ->
                val correct = viewModel.verifyPin(enteredPin)
                if (correct) {
                    showAppLockPrompt = false
                }
                correct
            },
            onDismiss = {
                // Keep showing until verified or exit
            }
        )
    }

    Scaffold(
        modifier = Modifier.fillMaxSize(),
        snackbarHost = { SnackbarHost(snackbarHostState) }
    ) { innerPadding ->
        AnimatedContent(
            targetState = currentScreen,
            transitionSpec = { fadeIn() togetherWith fadeOut() },
            label = "screen_transition",
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) { screen ->
            when (screen) {
                ScreenState.HOME -> {
                    HomeScreen(
                        viewModel = viewModel,
                        onNavigateToAddApp = { currentScreen = ScreenState.ADD_APP },
                        onNavigateToManage = { cloneId ->
                            selectedManageCloneId = cloneId
                            currentScreen = ScreenState.MANAGE_CLONE
                        },
                        onNavigateToArchitecture = { currentScreen = ScreenState.ARCHITECTURE },
                        onNavigateToSettings = { currentScreen = ScreenState.SETTINGS },
                        onOpenContainer = { target ->
                            containerClone = target
                            currentScreen = ScreenState.CONTAINER_RUNNER
                        }
                    )
                }

                ScreenState.ADD_APP -> {
                    BackHandler { currentScreen = ScreenState.HOME }
                    AddAppScreen(
                        viewModel = viewModel,
                        onNavigateBack = { currentScreen = ScreenState.HOME }
                    )
                }

                ScreenState.MANAGE_CLONE -> {
                    BackHandler { currentScreen = ScreenState.HOME }
                    ManageCloneScreen(
                        cloneId = selectedManageCloneId ?: "",
                        viewModel = viewModel,
                        onNavigateBack = { currentScreen = ScreenState.HOME },
                        onOpenContainer = { target ->
                            containerClone = target
                            currentScreen = ScreenState.CONTAINER_RUNNER
                        }
                    )
                }

                ScreenState.ARCHITECTURE -> {
                    BackHandler { currentScreen = ScreenState.HOME }
                    ArchitectureScreen(
                        viewModel = viewModel,
                        onNavigateBack = { currentScreen = ScreenState.HOME }
                    )
                }

                ScreenState.SETTINGS -> {
                    BackHandler { currentScreen = ScreenState.HOME }
                    SettingsScreen(
                        viewModel = viewModel,
                        onNavigateBack = { currentScreen = ScreenState.HOME },
                        onNavigateToArchitecture = { currentScreen = ScreenState.ARCHITECTURE }
                    )
                }

                ScreenState.CONTAINER_RUNNER -> {
                    BackHandler { currentScreen = ScreenState.HOME }
                    if (containerClone != null) {
                        ContainerRunnerScreen(
                            clone = containerClone!!,
                            onClose = {
                                viewModel.closeContainerRunner()
                                currentScreen = ScreenState.HOME
                            }
                        )
                    } else {
                        currentScreen = ScreenState.HOME
                    }
                }
            }
        }
    }
}
