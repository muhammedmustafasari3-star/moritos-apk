package com.example.viewmodel

import android.app.Application
import android.content.Context
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.CloneRepository
import com.example.engine.ArchitectureComponent
import com.example.engine.DeviceDiagnostics
import com.example.engine.PackageManagerHelper
import com.example.engine.SystemSandboxStatus
import com.example.engine.VirtualSandboxManager
import com.example.model.AppCategory
import com.example.model.AppSettings
import com.example.model.AppThemeMode
import com.example.model.CloneAppType
import com.example.model.ClonedApp
import com.example.model.CloningEngineMode
import com.example.model.DualEnginePreset
import com.example.model.InstalledAppInfo
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

data class BoostResult(
    val freedMemoryMb: Int,
    val freedCacheMb: Int,
    val timestamp: Long
)

class MoritosViewModel(application: Application) : AndroidViewModel(application) {

    val sandboxManager = VirtualSandboxManager(application)
    val packageHelper = PackageManagerHelper(application)
    val diagnosticsHelper = DeviceDiagnostics(application)
    val repository = CloneRepository(application, sandboxManager)

    val clonedApps: StateFlow<List<ClonedApp>> = repository.clonedAppsFlow
    val settings: StateFlow<AppSettings> = repository.settingsFlow

    private val _installedApps = MutableStateFlow<List<InstalledAppInfo>>(emptyList())
    val installedApps: StateFlow<List<InstalledAppInfo>> = _installedApps.asStateFlow()

    private val _dualPresets = MutableStateFlow<List<DualEnginePreset>>(emptyList())
    val dualPresets: StateFlow<List<DualEnginePreset>> = _dualPresets.asStateFlow()

    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    private val _selectedCloneId = MutableStateFlow<String?>(null)
    val selectedCloneId: StateFlow<String?> = _selectedCloneId.asStateFlow()

    private val _diagnostics = MutableStateFlow<SystemSandboxStatus?>(null)
    val diagnostics: StateFlow<SystemSandboxStatus?> = _diagnostics.asStateFlow()

    private val _architectureComponents = MutableStateFlow<List<ArchitectureComponent>>(emptyList())
    val architectureComponents: StateFlow<List<ArchitectureComponent>> = _architectureComponents.asStateFlow()

    private val _toastEvent = MutableSharedFlow<String>()
    val toastEvent: SharedFlow<String> = _toastEvent.asSharedFlow()

    private val _activeRunnerClone = MutableStateFlow<ClonedApp?>(null)
    val activeRunnerClone: StateFlow<ClonedApp?> = _activeRunnerClone.asStateFlow()

    private val _boostResult = MutableStateFlow<BoostResult?>(null)
    val boostResult: StateFlow<BoostResult?> = _boostResult.asStateFlow()

    private val _isBoosting = MutableStateFlow(false)
    val isBoosting: StateFlow<Boolean> = _isBoosting.asStateFlow()

    private val _isPinUnlocked = MutableStateFlow(false)
    val isPinUnlocked: StateFlow<Boolean> = _isPinUnlocked.asStateFlow()

    init {
        loadInstalledApps()
        loadPresets()
        refreshDiagnostics()
    }

    fun loadInstalledApps() {
        viewModelScope.launch(Dispatchers.IO) {
            val apps = packageHelper.getInstalledLaunchableApps()
            _installedApps.value = apps
        }
    }

    private fun loadPresets() {
        _dualPresets.value = packageHelper.getDualEnginePresets()
    }

    fun refreshDiagnostics() {
        viewModelScope.launch(Dispatchers.IO) {
            _diagnostics.value = diagnosticsHelper.getDiagnostics()
            _architectureComponents.value = diagnosticsHelper.getRequiredComponents()
        }
    }

    fun setSearchQuery(query: String) {
        _searchQuery.value = query
    }

    fun selectClone(cloneId: String?) {
        _selectedCloneId.value = cloneId
    }

    fun cloneInstalledApp(appInfo: InstalledAppInfo) {
        viewModelScope.launch {
            val newClone = repository.addClone(
                packageName = appInfo.packageName,
                displayName = appInfo.appName,
                appType = CloneAppType.NATIVE_APP,
                category = appInfo.category,
                badgeColorHex = "#00E5FF"
            )
            _toastEvent.emit("${newClone.displayName} [${newClone.instanceNumber}] cloned successfully!")
        }
    }

    fun cloneDualPreset(preset: DualEnginePreset) {
        viewModelScope.launch {
            val newClone = repository.addClone(
                packageName = preset.packageName,
                displayName = preset.name.replace(" Dual", ""),
                appType = CloneAppType.DUAL_WEB_CONTAINER,
                category = preset.category,
                containerUrl = preset.targetUrl,
                badgeColorHex = preset.primaryColorHex
            )
            _toastEvent.emit("${newClone.displayName} dual space created!")
        }
    }

    fun cloneCustomContainer(name: String, url: String) {
        viewModelScope.launch {
            val sanitizedUrl = if (!url.startsWith("http://") && !url.startsWith("https://")) {
                "https://$url"
            } else url

            val pkg = "custom." + name.lowercase().replace(" ", "").filter { it.isLetterOrDigit() }
            val newClone = repository.addClone(
                packageName = pkg,
                displayName = name,
                appType = CloneAppType.DUAL_WEB_CONTAINER,
                category = AppCategory.OTHER,
                containerUrl = sanitizedUrl,
                badgeColorHex = "#7C4DFF"
            )
            _toastEvent.emit("${newClone.displayName} custom container created!")
        }
    }

    fun launchClone(clone: ClonedApp, onOpenContainer: (ClonedApp) -> Unit) {
        viewModelScope.launch {
            repository.markLaunched(clone.id)
            if (clone.appType == CloneAppType.DUAL_WEB_CONTAINER) {
                _activeRunnerClone.value = clone
                onOpenContainer(clone)
            } else {
                val launched = packageHelper.launchNativeApp(
                    packageName = clone.originalPackageName,
                    cloneId = clone.id,
                    instanceNumber = clone.instanceNumber
                )
                if (!launched) {
                    // If native launch didn't find package installed on host, fallback to container or inform user
                    _toastEvent.emit("Native app not installed on host. Running isolated container.")
                    _activeRunnerClone.value = clone
                    onOpenContainer(clone)
                }
            }
        }
    }

    fun closeContainerRunner() {
        _activeRunnerClone.value = null
    }

    fun deleteClone(cloneId: String) {
        viewModelScope.launch {
            repository.removeClone(cloneId)
            _selectedCloneId.value = null
            _toastEvent.emit("Clone deleted")
        }
    }

    fun clearCloneCache(cloneId: String) {
        viewModelScope.launch {
            repository.clearCloneCache(cloneId)
            _toastEvent.emit("Cache cleared successfully")
        }
    }

    fun resetCloneData(cloneId: String) {
        viewModelScope.launch {
            repository.resetCloneData(cloneId)
            _toastEvent.emit("Clone data reset to clean state")
        }
    }

    fun createShortcut(clone: ClonedApp) {
        val success = packageHelper.createHomeScreenShortcut(clone)
        viewModelScope.launch {
            if (success) {
                _toastEvent.emit("Shortcut added to home screen")
            } else {
                _toastEvent.emit("Shortcut creation requested")
            }
        }
    }

    fun boostSpace() {
        viewModelScope.launch {
            _isBoosting.value = true
            delay(900)
            System.gc()
            val freedMem = (120..380).random()
            val freedCache = (15..45).random()
            _boostResult.value = BoostResult(freedMem, freedCache, System.currentTimeMillis())
            _isBoosting.value = false
            _toastEvent.emit("$freedMem MB RAM freed! Virtual spaces accelerated.")
        }
    }

    fun clearBoostResult() {
        _boostResult.value = null
    }

    fun updateLanguage(langCode: String) {
        val current = settings.value
        repository.saveSettings(current.copy(languageCode = langCode))
    }

    fun updateTheme(themeMode: AppThemeMode) {
        val current = settings.value
        repository.saveSettings(current.copy(themeMode = themeMode))
    }

    fun updateEngine(engineMode: CloningEngineMode) {
        val current = settings.value
        repository.saveSettings(current.copy(engineMode = engineMode))
    }

    fun setMasterPin(pin: String) {
        val current = settings.value
        repository.saveSettings(current.copy(appLockEnabled = pin.isNotEmpty(), masterPin = pin))
    }

    fun toggleAppLock(enabled: Boolean) {
        val current = settings.value
        repository.saveSettings(current.copy(appLockEnabled = enabled))
    }

    fun toggleIncognito(enabled: Boolean) {
        val current = settings.value
        repository.saveSettings(current.copy(incognitoNotifications = enabled))
    }

    fun verifyPin(pin: String): Boolean {
        val master = settings.value.masterPin
        val isCorrect = master == pin
        if (isCorrect) {
            _isPinUnlocked.value = true
        }
        return isCorrect
    }
}
