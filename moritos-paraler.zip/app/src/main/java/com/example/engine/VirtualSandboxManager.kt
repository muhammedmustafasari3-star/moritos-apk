package com.example.engine

import android.content.Context
import android.util.Log
import java.io.File

/**
 * Manages genuine isolated filesystem containers for cloned application instances.
 * In native Android, each application instance requires its own private data,
 * cache, preferences, and database trees.
 */
class VirtualSandboxManager(private val context: Context) {

    private val baseSpacesDir: File by lazy {
        File(context.filesDir, "virtual_spaces").apply {
            if (!exists()) mkdirs()
        }
    }

    /**
     * Initializes a dedicated, isolated sandbox for a clone instance
     */
    fun initializeVirtualSpace(cloneId: String, packageName: String): File {
        val spaceDir = File(baseSpacesDir, cloneId)
        val dataDir = File(spaceDir, "data/data/$packageName")
        val cacheDir = File(spaceDir, "cache")
        val dbDir = File(spaceDir, "databases")
        val prefsDir = File(spaceDir, "shared_prefs")
        val filesDir = File(spaceDir, "files")

        dataDir.mkdirs()
        cacheDir.mkdirs()
        dbDir.mkdirs()
        prefsDir.mkdirs()
        filesDir.mkdirs()

        // Create a metadata marker file
        File(spaceDir, "moritos_space_meta.json").writeText(
            """
            {
              "cloneId": "$cloneId",
              "packageName": "$packageName",
              "created": ${System.currentTimeMillis()},
              "status": "INITIALIZED"
            }
            """.trimIndent()
        )

        return spaceDir
    }

    /**
     * Returns the virtual space root directory for a clone
     */
    fun getVirtualSpaceDir(cloneId: String): File {
        return File(baseSpacesDir, cloneId)
    }

    /**
     * Calculates the real byte size of a virtual container's data
     */
    fun calculateVirtualDataSize(cloneId: String): Long {
        val spaceDir = File(baseSpacesDir, cloneId)
        if (!spaceDir.exists()) return 0L
        return getFolderSize(spaceDir)
    }

    /**
     * Calculates the real byte size of the virtual container's cache
     */
    fun calculateVirtualCacheSize(cloneId: String): Long {
        val cacheDir = File(baseSpacesDir, "$cloneId/cache")
        if (!cacheDir.exists()) return 0L
        return getFolderSize(cacheDir)
    }

    /**
     * Clears all cache files for the clone
     */
    fun clearVirtualCache(cloneId: String): Boolean {
        val cacheDir = File(baseSpacesDir, "$cloneId/cache")
        return if (cacheDir.exists()) {
            cacheDir.deleteRecursively().also {
                cacheDir.mkdirs()
            }
        } else {
            true
        }
    }

    /**
     * Resets the clone's virtual data to fresh state
     */
    fun resetVirtualData(cloneId: String, packageName: String): Boolean {
        val spaceDir = File(baseSpacesDir, cloneId)
        if (spaceDir.exists()) {
            spaceDir.deleteRecursively()
        }
        initializeVirtualSpace(cloneId, packageName)
        return true
    }

    /**
     * Deletes the entire virtual container
     */
    fun deleteVirtualSpace(cloneId: String): Boolean {
        val spaceDir = File(baseSpacesDir, cloneId)
        return if (spaceDir.exists()) {
            spaceDir.deleteRecursively()
        } else {
            true
        }
    }

    /**
     * Formats bytes to readable MB/KB string
     */
    fun formatBytes(bytes: Long): String {
        return when {
            bytes >= 1024 * 1024 * 1024 -> String.format("%.2f GB", bytes.toDouble() / (1024 * 1024 * 1024))
            bytes >= 1024 * 1024 -> String.format("%.1f MB", bytes.toDouble() / (1024 * 1024))
            bytes >= 1024 -> String.format("%.1f KB", bytes.toDouble() / 1024)
            else -> "$bytes B"
        }
    }

    private fun getFolderSize(file: File): Long {
        var size = 0L
        try {
            val children = file.listFiles() ?: return file.length()
            for (child in children) {
                size += if (child.isDirectory) {
                    getFolderSize(child)
                } else {
                    child.length()
                }
            }
        } catch (e: Exception) {
            Log.w("VirtualSandboxManager", "Failed to measure folder size: ${e.message}")
        }
        return size
    }
}
