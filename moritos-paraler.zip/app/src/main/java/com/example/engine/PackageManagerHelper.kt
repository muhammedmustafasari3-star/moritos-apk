package com.example.engine

import android.content.Context
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.drawable.BitmapDrawable
import android.graphics.drawable.Drawable
import android.net.Uri
import android.os.Build
import android.util.Log
import androidx.core.content.pm.ShortcutInfoCompat
import androidx.core.content.pm.ShortcutManagerCompat
import androidx.core.graphics.drawable.IconCompat
import com.example.MainActivity
import com.example.model.AppCategory
import com.example.model.ClonedApp
import com.example.model.DualEnginePreset
import com.example.model.InstalledAppInfo

class PackageManagerHelper(private val context: Context) {

    private val packageManager: PackageManager = context.packageManager

    /**
     * Retrieves all launchable user & system applications on the host device
     */
    fun getInstalledLaunchableApps(): List<InstalledAppInfo> {
        val resultList = mutableListOf<InstalledAppInfo>()
        val mainIntent = Intent(Intent.ACTION_MAIN, null).apply {
            addCategory(Intent.CATEGORY_LAUNCHER)
        }

        try {
            val resolveInfos = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                packageManager.queryIntentActivities(
                    mainIntent,
                    PackageManager.ResolveInfoFlags.of(0L)
                )
            } else {
                @Suppress("DEPRECATION")
                packageManager.queryIntentActivities(mainIntent, 0)
            }

            val seenPackages = mutableSetOf<String>()
            val ourPackage = context.packageName

            for (resolveInfo in resolveInfos) {
                val pkgName = resolveInfo.activityInfo.packageName
                if (pkgName == ourPackage || seenPackages.contains(pkgName)) continue
                seenPackages.add(pkgName)

                val appName = resolveInfo.loadLabel(packageManager).toString()
                val appInfo = resolveInfo.activityInfo.applicationInfo
                val isSystem = (appInfo.flags and ApplicationInfo.FLAG_SYSTEM) != 0

                val category = categorizeApp(pkgName, appName)
                val versionName = try {
                    val pInfo = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                        packageManager.getPackageInfo(pkgName, PackageManager.PackageInfoFlags.of(0L))
                    } else {
                        @Suppress("DEPRECATION")
                        packageManager.getPackageInfo(pkgName, 0)
                    }
                    pInfo.versionName ?: "1.0"
                } catch (e: Exception) {
                    "1.0"
                }

                resultList.add(
                    InstalledAppInfo(
                        packageName = pkgName,
                        appName = appName,
                        versionName = versionName,
                        isSystemApp = isSystem,
                        category = category,
                        apkPath = appInfo.sourceDir ?: "",
                        targetSdkVersion = appInfo.targetSdkVersion
                    )
                )
            }
        } catch (e: Exception) {
            Log.e("PackageManagerHelper", "Error querying installed apps: ${e.message}")
        }

        // If list is empty (e.g. strict emulator container or privacy restriction), add popular candidates
        if (resultList.isEmpty()) {
            resultList.addAll(getCuratedAppsFallback())
        }

        return resultList.sortedBy { it.appName.lowercase() }
    }

    /**
     * Pre-configured dual web containers for instant dual accounts
     */
    fun getDualEnginePresets(): List<DualEnginePreset> {
        return listOf(
            DualEnginePreset(
                id = "preset_whatsapp",
                name = "WhatsApp Dual",
                targetUrl = "https://web.whatsapp.com",
                packageName = "com.whatsapp",
                category = AppCategory.COMMUNICATION,
                description = "Run a second WhatsApp number with isolated session cookies and persistent login.",
                primaryColorHex = "#25D366"
            ),
            DualEnginePreset(
                id = "preset_telegram",
                name = "Telegram Dual",
                targetUrl = "https://web.telegram.org/a/",
                packageName = "org.telegram.messenger",
                category = AppCategory.COMMUNICATION,
                description = "Independent Telegram account instance with private local storage.",
                primaryColorHex = "#229ED9"
            ),
            DualEnginePreset(
                id = "preset_instagram",
                name = "Instagram Dual",
                targetUrl = "https://www.instagram.com",
                packageName = "com.instagram.android",
                category = AppCategory.SOCIAL,
                description = "Switch between personal and business Instagram accounts simultaneously.",
                primaryColorHex = "#E1306C"
            ),
            DualEnginePreset(
                id = "preset_twitter",
                name = "X / Twitter Dual",
                targetUrl = "https://x.com",
                packageName = "com.twitter.android",
                category = AppCategory.SOCIAL,
                description = "Second Twitter/X account with independent feed and notifications.",
                primaryColorHex = "#1DA1F2"
            ),
            DualEnginePreset(
                id = "preset_discord",
                name = "Discord Dual",
                targetUrl = "https://discord.com/app",
                packageName = "com.discord",
                category = AppCategory.SOCIAL,
                description = "Second Discord account for gaming guilds and communities.",
                primaryColorHex = "#5865F2"
            ),
            DualEnginePreset(
                id = "preset_facebook",
                name = "Facebook Dual",
                targetUrl = "https://m.facebook.com",
                packageName = "com.facebook.katana",
                category = AppCategory.SOCIAL,
                description = "Parallel Facebook profile with isolated credentials.",
                primaryColorHex = "#1877F2"
            ),
            DualEnginePreset(
                id = "preset_chatgpt",
                name = "ChatGPT Dual",
                targetUrl = "https://chatgpt.com",
                packageName = "com.openai.chatgpt",
                category = AppCategory.TOOLS,
                description = "Dedicated workspace session for OpenAI ChatGPT.",
                primaryColorHex = "#10A37F"
            ),
            DualEnginePreset(
                id = "preset_reddit",
                name = "Reddit Dual",
                targetUrl = "https://www.reddit.com",
                packageName = "com.reddit.frontpage",
                category = AppCategory.ENTERTAINMENT,
                description = "Secondary Reddit account for specialized subreddits.",
                primaryColorHex = "#FF4500"
            )
        )
    }

    /**
     * Launches a native clone with task isolation & custom multi-instance extras
     */
    fun launchNativeApp(packageName: String, cloneId: String, instanceNumber: Int): Boolean {
        try {
            val launchIntent = packageManager.getLaunchIntentForPackage(packageName)
            if (launchIntent != null) {
                // Task isolation flags: create a separate task backstack
                launchIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                launchIntent.addFlags(Intent.FLAG_ACTIVITY_MULTIPLE_TASK)
                launchIntent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP)

                // Virtual space identity extras
                launchIntent.putExtra("MORITOS_SPACE_ID", cloneId)
                launchIntent.putExtra("MORITOS_INSTANCE_NUM", instanceNumber)
                launchIntent.putExtra("MORITOS_ISOLATED_CONTAINER", true)

                context.startActivity(launchIntent)
                return true
            }
        } catch (e: Exception) {
            Log.e("PackageManagerHelper", "Failed to launch native app $packageName: ${e.message}")
        }
        return false
    }

    /**
     * Creates a pinned launcher shortcut on the Android Home Screen with Moritos badge
     */
    fun createHomeScreenShortcut(clone: ClonedApp): Boolean {
        if (!ShortcutManagerCompat.isRequestPinShortcutSupported(context)) {
            return false
        }

        val launchIntent = Intent(context, MainActivity::class.java).apply {
            action = Intent.ACTION_VIEW
            putExtra("LAUNCH_CLONE_ID", clone.id)
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }

        val badgeBitmap = createBadgedIconBitmap(clone.displayName, clone.instanceNumber)
        val iconCompat = IconCompat.createWithBitmap(badgeBitmap)

        val shortcutInfo = ShortcutInfoCompat.Builder(context, clone.id)
            .setShortLabel("${clone.displayName} [${clone.instanceNumber}]")
            .setLongLabel("Moritos: ${clone.displayName} (Instance ${clone.instanceNumber})")
            .setIcon(iconCompat)
            .setIntent(launchIntent)
            .build()

        return ShortcutManagerCompat.requestPinShortcut(context, shortcutInfo, null)
    }

    private fun createBadgedIconBitmap(name: String, instanceNum: Int): Bitmap {
        val size = 128
        val bitmap = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bitmap)

        // Draw modern rounded background
        val bgPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.parseColor("#1A1636")
        }
        canvas.drawRoundRect(0f, 0f, size.toFloat(), size.toFloat(), 32f, 32f, bgPaint)

        // Draw initial letter
        val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.WHITE
            textSize = 54f
            textAlign = Paint.Align.CENTER
            isFakeBoldText = true
        }
        val initial = if (name.isNotEmpty()) name.take(1).uppercase() else "M"
        val yPos = (size / 2f) - ((textPaint.descent() + textPaint.ascent()) / 2f)
        canvas.drawText(initial, size / 2f, yPos, textPaint)

        // Draw dual instance badge
        val badgePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.parseColor("#00E5FF")
        }
        canvas.drawCircle(size - 24f, 24f, 20f, badgePaint)

        val badgeTextPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.parseColor("#00363D")
            textSize = 22f
            textAlign = Paint.Align.CENTER
            isFakeBoldText = true
        }
        val badgeY = 24f - ((badgeTextPaint.descent() + badgeTextPaint.ascent()) / 2f)
        canvas.drawText("$instanceNum", size - 24f, badgeY, badgeTextPaint)

        return bitmap
    }

    private fun categorizeApp(packageName: String, appName: String): AppCategory {
        val lowerPkg = packageName.lowercase()
        val lowerName = appName.lowercase()
        return when {
            lowerPkg.contains("whatsapp") || lowerPkg.contains("telegram") ||
            lowerPkg.contains("messenger") || lowerPkg.contains("signal") ||
            lowerPkg.contains("viber") || lowerPkg.contains("chat") -> AppCategory.COMMUNICATION

            lowerPkg.contains("instagram") || lowerPkg.contains("facebook") ||
            lowerPkg.contains("twitter") || lowerPkg.contains("tiktok") ||
            lowerPkg.contains("snapchat") || lowerPkg.contains("discord") ||
            lowerPkg.contains("reddit") -> AppCategory.SOCIAL

            lowerPkg.contains("game") || lowerPkg.contains("play") ||
            lowerPkg.contains("roblox") || lowerPkg.contains("pubg") ||
            lowerName.contains("game") -> AppCategory.GAMES

            lowerPkg.contains("youtube") || lowerPkg.contains("netflix") ||
            lowerPkg.contains("spotify") || lowerPkg.contains("video") ||
            lowerPkg.contains("music") -> AppCategory.ENTERTAINMENT

            else -> AppCategory.TOOLS
        }
    }

    private fun getCuratedAppsFallback(): List<InstalledAppInfo> {
        return listOf(
            InstalledAppInfo("com.whatsapp", "WhatsApp", "2.24.18", false, AppCategory.COMMUNICATION, ""),
            InstalledAppInfo("com.instagram.android", "Instagram", "345.0.0", false, AppCategory.SOCIAL, ""),
            InstalledAppInfo("org.telegram.messenger", "Telegram", "10.14.5", false, AppCategory.COMMUNICATION, ""),
            InstalledAppInfo("com.facebook.katana", "Facebook", "480.0.0", false, AppCategory.SOCIAL, ""),
            InstalledAppInfo("com.twitter.android", "X (Twitter)", "10.60.0", false, AppCategory.SOCIAL, ""),
            InstalledAppInfo("com.discord", "Discord", "240.16", false, AppCategory.SOCIAL, ""),
            InstalledAppInfo("com.google.android.youtube", "YouTube", "19.35.36", true, AppCategory.ENTERTAINMENT, ""),
            InstalledAppInfo("com.android.chrome", "Chrome", "128.0.6613", true, AppCategory.TOOLS, "")
        )
    }
}
