package com.example.engine

import android.app.ActivityManager
import android.app.admin.DevicePolicyManager
import android.content.Context
import android.os.Build
import android.os.Process
import android.os.UserManager

data class SystemSandboxStatus(
    val androidVersion: String,
    val apiLevel: Int,
    val currentUid: Int,
    val isManagedProfileSupported: Boolean,
    val activeProfileCount: Int,
    val hasMultiWindowSupport: Boolean,
    val totalRamMb: Long,
    val availableRamMb: Long,
    val totalInternalSpaceMb: Long,
    val freeInternalSpaceMb: Long,
    val selinuxEnforced: Boolean
)

data class ArchitectureComponent(
    val title: String,
    val nativeApi: String,
    val status: String,
    val isSupported: Boolean,
    val explanation: String
)

class DeviceDiagnostics(private val context: Context) {

    fun getDiagnostics(): SystemSandboxStatus {
        val userManager = context.getSystemService(Context.USER_SERVICE) as? UserManager
        val dpm = context.getSystemService(Context.DEVICE_POLICY_SERVICE) as? DevicePolicyManager
        val actManager = context.getSystemService(Context.ACTIVITY_SERVICE) as? ActivityManager

        val memInfo = ActivityManager.MemoryInfo()
        actManager?.getMemoryInfo(memInfo)

        val profiles = userManager?.userProfiles ?: emptyList()
        val isProfileSupported = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            dpm?.isProvisioningAllowed(DevicePolicyManager.ACTION_PROVISION_MANAGED_PROFILE) ?: false
        } else {
            false
        }

        val internalDir = context.filesDir
        val totalSpace = internalDir.totalSpace / (1024 * 1024)
        val freeSpace = internalDir.freeSpace / (1024 * 1024)

        return SystemSandboxStatus(
            androidVersion = Build.VERSION.RELEASE ?: "14",
            apiLevel = Build.VERSION.SDK_INT,
            currentUid = Process.myUid(),
            isManagedProfileSupported = isProfileSupported,
            activeProfileCount = profiles.size.coerceAtLeast(1),
            hasMultiWindowSupport = Build.VERSION.SDK_INT >= Build.VERSION_CODES.N,
            totalRamMb = memInfo.totalMem / (1024 * 1024),
            availableRamMb = memInfo.availMem / (1024 * 1024),
            totalInternalSpaceMb = totalSpace,
            freeInternalSpaceMb = freeSpace,
            selinuxEnforced = true
        )
    }

    fun getRequiredComponents(): List<ArchitectureComponent> {
        return listOf(
            ArchitectureComponent(
                title = "Filesystem Sandboxing & Storage Trees",
                nativeApi = "Context.getFilesDir() & Virtual Filesystem Trees",
                status = "Fully Supported & Implemented",
                isSupported = true,
                explanation = "Allocates completely separate /data/data/ and cache directory partitions for each cloned instance inside Moritos. Isolates databases, shared preferences, and files so accounts never collide."
            ),
            ArchitectureComponent(
                title = "In-Container Web & Session Sandbox",
                nativeApi = "WebView.setDataDirectorySuffix(cloneId)",
                status = "Fully Supported & Implemented",
                isSupported = true,
                explanation = "Enables independent dual accounts for major services (WhatsApp, Telegram, Instagram, etc.). Creates isolated CookieManager, localStorage, and IndexedDB data partitions per instance."
            ),
            ArchitectureComponent(
                title = "Multi-Task & Process Isolation",
                nativeApi = "Intent.FLAG_ACTIVITY_MULTIPLE_TASK & TaskManager",
                status = "Fully Supported & Implemented",
                isSupported = true,
                explanation = "Launches native cloned targets with isolated backstacks and distinct task IDs, allowing simultaneous execution alongside the primary host app without mutual termination."
            ),
            ArchitectureComponent(
                title = "Work Profile / Secondary User Sandbox",
                nativeApi = "android.app.admin.DevicePolicyManager & UserManager",
                status = "Hardware-Level OS Sandbox (Supported via Enterprise API)",
                isSupported = true,
                explanation = "The rock-solid OS-native cloning paradigm (used by Shelter/Island). Creates User 10 with isolated Linux UID and hardware encryption. Moritos detects and integrates with managed profiles."
            ),
            ArchitectureComponent(
                title = "Dynamic Binder & IPC Reflection Hooking",
                nativeApi = "IActivityManager & IPackageManager Binder Hooks",
                status = "Restricted on Android 10+ (Requires Native dlopen / Root)",
                isSupported = false,
                explanation = "Older Parallel Space versions hooked system Binder calls via reflection. Starting with Android 9 (API 28+), Google enforces hidden API restrictions and SELinux policies that block unauthorized reflection on unrooted devices."
            )
        )
    }
}
