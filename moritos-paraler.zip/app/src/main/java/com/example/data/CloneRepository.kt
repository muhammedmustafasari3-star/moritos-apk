package com.example.data

import android.content.Context
import android.content.SharedPreferences
import com.example.engine.VirtualSandboxManager
import com.example.model.AppCategory
import com.example.model.AppSettings
import com.example.model.AppThemeMode
import com.example.model.CloneAppType
import com.example.model.ClonedApp
import com.example.model.CloningEngineMode
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject

class CloneRepository(
    private val context: Context,
    private val sandboxManager: VirtualSandboxManager
) {
    private val prefs: SharedPreferences =
        context.getSharedPreferences("moritos_clones_prefs", Context.MODE_PRIVATE)

    private val _clonedAppsFlow = MutableStateFlow<List<ClonedApp>>(emptyList())
    val clonedAppsFlow: StateFlow<List<ClonedApp>> = _clonedAppsFlow.asStateFlow()

    private val _settingsFlow = MutableStateFlow(AppSettings())
    val settingsFlow: StateFlow<AppSettings> = _settingsFlow.asStateFlow()

    init {
        loadSettings()
        loadClones()
    }

    private fun loadSettings() {
        val lang = prefs.getString("setting_lang", "en") ?: "en"
        val themeStr = prefs.getString("setting_theme", AppThemeMode.DARK.name) ?: AppThemeMode.DARK.name
        val engineStr = prefs.getString("setting_engine", CloningEngineMode.IN_CONTAINER_SANDBOX.name) ?: CloningEngineMode.IN_CONTAINER_SANDBOX.name
        val lockEnabled = prefs.getBoolean("setting_lock_enabled", false)
        val pin = prefs.getString("setting_pin", "") ?: ""
        val incognito = prefs.getBoolean("setting_incognito", false)

        val theme = try { AppThemeMode.valueOf(themeStr) } catch (e: Exception) { AppThemeMode.DARK }
        val engine = try { CloningEngineMode.valueOf(engineStr) } catch (e: Exception) { CloningEngineMode.IN_CONTAINER_SANDBOX }

        _settingsFlow.value = AppSettings(
            languageCode = lang,
            themeMode = theme,
            engineMode = engine,
            appLockEnabled = lockEnabled,
            masterPin = pin,
            incognitoNotifications = incognito
        )
    }

    fun saveSettings(settings: AppSettings) {
        prefs.edit()
            .putString("setting_lang", settings.languageCode)
            .putString("setting_theme", settings.themeMode.name)
            .putString("setting_engine", settings.engineMode.name)
            .putBoolean("setting_lock_enabled", settings.appLockEnabled)
            .putString("setting_pin", settings.masterPin)
            .putBoolean("setting_incognito", settings.incognitoNotifications)
            .apply()
        _settingsFlow.value = settings
    }

    private fun loadClones() {
        val rawJson = prefs.getString("clones_json", null)
        val list = mutableListOf<ClonedApp>()

        if (!rawJson.isNullOrEmpty()) {
            try {
                val array = JSONArray(rawJson)
                for (i in 0 until array.length()) {
                    val obj = array.getJSONObject(i)
                    list.add(parseCloneJson(obj))
                }
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }

        // If fresh install, pre-seed two popular dual containers for immediate Parallel Space experience
        if (list.isEmpty()) {
            val initialWhatsapp = ClonedApp(
                id = "clone_whatsapp_2",
                originalPackageName = "com.whatsapp",
                displayName = "WhatsApp",
                instanceNumber = 2,
                appType = CloneAppType.DUAL_WEB_CONTAINER,
                category = AppCategory.COMMUNICATION,
                createdTimestamp = System.currentTimeMillis() - 86400000,
                lastLaunchedTimestamp = System.currentTimeMillis() - 3600000,
                isLocked = false,
                containerUrl = "https://web.whatsapp.com",
                badgeColorHex = "#25D366"
            )
            val initialTelegram = ClonedApp(
                id = "clone_telegram_2",
                originalPackageName = "org.telegram.messenger",
                displayName = "Telegram",
                instanceNumber = 2,
                appType = CloneAppType.DUAL_WEB_CONTAINER,
                category = AppCategory.COMMUNICATION,
                createdTimestamp = System.currentTimeMillis() - 43200000,
                lastLaunchedTimestamp = System.currentTimeMillis() - 7200000,
                isLocked = false,
                containerUrl = "https://web.telegram.org/a/",
                badgeColorHex = "#229ED9"
            )

            sandboxManager.initializeVirtualSpace(initialWhatsapp.id, initialWhatsapp.originalPackageName)
            sandboxManager.initializeVirtualSpace(initialTelegram.id, initialTelegram.originalPackageName)

            list.add(initialWhatsapp)
            list.add(initialTelegram)
            saveClonesInternal(list)
        }

        // Refresh disk measurements
        val refreshed = list.map { clone ->
            val dataBytes = sandboxManager.calculateVirtualDataSize(clone.id)
            val cacheBytes = sandboxManager.calculateVirtualCacheSize(clone.id)
            clone.copy(
                virtualDataSizeBytes = if (dataBytes > 0) dataBytes else 12500000L, // Simulated baseline 12.5MB if new
                cacheSizeBytes = if (cacheBytes > 0) cacheBytes else 3400000L
            )
        }

        _clonedAppsFlow.value = refreshed
    }

    suspend fun addClone(
        packageName: String,
        displayName: String,
        appType: CloneAppType,
        category: AppCategory,
        containerUrl: String? = null,
        badgeColorHex: String = "#00E5FF"
    ): ClonedApp = withContext(Dispatchers.IO) {
        val currentList = _clonedAppsFlow.value
        val existingCount = currentList.count { it.originalPackageName == packageName }
        val nextInstance = existingCount + 2 // 2nd, 3rd, etc.
        val cloneId = "clone_${packageName.replace(".", "_")}_$nextInstance"

        sandboxManager.initializeVirtualSpace(cloneId, packageName)

        val newClone = ClonedApp(
            id = cloneId,
            originalPackageName = packageName,
            displayName = displayName,
            instanceNumber = nextInstance,
            appType = appType,
            category = category,
            createdTimestamp = System.currentTimeMillis(),
            lastLaunchedTimestamp = System.currentTimeMillis(),
            isLocked = false,
            virtualDataSizeBytes = 8400000L, // Initial virtual image
            cacheSizeBytes = 1200000L,
            containerUrl = containerUrl,
            badgeColorHex = badgeColorHex
        )

        val updated = currentList + newClone
        saveClonesInternal(updated)
        _clonedAppsFlow.value = updated
        newClone
    }

    suspend fun removeClone(cloneId: String) = withContext(Dispatchers.IO) {
        sandboxManager.deleteVirtualSpace(cloneId)
        val updated = _clonedAppsFlow.value.filterNot { it.id == cloneId }
        saveClonesInternal(updated)
        _clonedAppsFlow.value = updated
    }

    suspend fun updateClone(updatedClone: ClonedApp) = withContext(Dispatchers.IO) {
        val updated = _clonedAppsFlow.value.map {
            if (it.id == updatedClone.id) updatedClone else it
        }
        saveClonesInternal(updated)
        _clonedAppsFlow.value = updated
    }

    suspend fun clearCloneCache(cloneId: String) = withContext(Dispatchers.IO) {
        sandboxManager.clearVirtualCache(cloneId)
        val updated = _clonedAppsFlow.value.map {
            if (it.id == cloneId) it.copy(cacheSizeBytes = 0L) else it
        }
        saveClonesInternal(updated)
        _clonedAppsFlow.value = updated
    }

    suspend fun resetCloneData(cloneId: String) = withContext(Dispatchers.IO) {
        val clone = _clonedAppsFlow.value.find { it.id == cloneId } ?: return@withContext
        sandboxManager.resetVirtualData(cloneId, clone.originalPackageName)
        val updated = _clonedAppsFlow.value.map {
            if (it.id == cloneId) it.copy(virtualDataSizeBytes = 512000L, cacheSizeBytes = 0L) else it
        }
        saveClonesInternal(updated)
        _clonedAppsFlow.value = updated
    }

    suspend fun markLaunched(cloneId: String) = withContext(Dispatchers.IO) {
        val updated = _clonedAppsFlow.value.map {
            if (it.id == cloneId) it.copy(lastLaunchedTimestamp = System.currentTimeMillis(), isRunning = true) else it
        }
        saveClonesInternal(updated)
        _clonedAppsFlow.value = updated
    }

    private fun saveClonesInternal(list: List<ClonedApp>) {
        val array = JSONArray()
        for (item in list) {
            val obj = JSONObject().apply {
                put("id", item.id)
                put("originalPackageName", item.originalPackageName)
                put("displayName", item.displayName)
                put("instanceNumber", item.instanceNumber)
                put("appType", item.appType.name)
                put("category", item.category.name)
                put("createdTimestamp", item.createdTimestamp)
                put("lastLaunchedTimestamp", item.lastLaunchedTimestamp)
                put("isLocked", item.isLocked)
                put("virtualDataSizeBytes", item.virtualDataSizeBytes)
                put("cacheSizeBytes", item.cacheSizeBytes)
                put("containerUrl", item.containerUrl ?: "")
                put("badgeColorHex", item.badgeColorHex)
                put("isRunning", item.isRunning)
                put("customNotes", item.customNotes)
            }
            array.put(obj)
        }
        prefs.edit().putString("clones_json", array.toString()).apply()
    }

    private fun parseCloneJson(obj: JSONObject): ClonedApp {
        val typeStr = obj.optString("appType", CloneAppType.NATIVE_APP.name)
        val catStr = obj.optString("category", AppCategory.OTHER.name)
        val appType = try { CloneAppType.valueOf(typeStr) } catch (e: Exception) { CloneAppType.NATIVE_APP }
        val category = try { AppCategory.valueOf(catStr) } catch (e: Exception) { AppCategory.OTHER }

        val url = obj.optString("containerUrl", "")
        return ClonedApp(
            id = obj.getString("id"),
            originalPackageName = obj.getString("originalPackageName"),
            displayName = obj.getString("displayName"),
            instanceNumber = obj.optInt("instanceNumber", 2),
            appType = appType,
            category = category,
            createdTimestamp = obj.optLong("createdTimestamp", System.currentTimeMillis()),
            lastLaunchedTimestamp = obj.optLong("lastLaunchedTimestamp", 0L),
            isLocked = obj.optBoolean("isLocked", false),
            virtualDataSizeBytes = obj.optLong("virtualDataSizeBytes", 0L),
            cacheSizeBytes = obj.optLong("cacheSizeBytes", 0L),
            containerUrl = if (url.isNotEmpty()) url else null,
            badgeColorHex = obj.optString("badgeColorHex", "#00E5FF"),
            isRunning = obj.optBoolean("isRunning", false),
            customNotes = obj.optString("customNotes", "")
        )
    }
}
