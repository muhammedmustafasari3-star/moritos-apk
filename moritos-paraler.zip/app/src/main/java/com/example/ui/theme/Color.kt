package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Moritos Brand Colors - Dual Space Signature Palette
val MoritosCyan = Color(0xFF00E5FF)
val MoritosViolet = Color(0xFF7C4DFF)
val MoritosDeepViolet = Color(0xFF5E35B1)
val MoritosTeal = Color(0xFF00BCD4)
val MoritosCoral = Color(0xFFFF5252)
val MoritosGold = Color(0xFFFFB300)
val MoritosGreen = Color(0xFF00E676)

// Dark Space Theme Colors
val DarkBackground = Color(0xFF0B0A17)
val DarkSurface = Color(0xFF131127)
val DarkSurfaceElevated = Color(0xFF1D1A38)
val DarkSurfaceVariant = Color(0xFF28234B)
val DarkOnBackground = Color(0xFFEDE9FC)
val DarkOnSurface = Color(0xFFEDE9FC)
val DarkOnSurfaceVariant = Color(0xFFC6C0E4)
val DarkOutline = Color(0xFF453D6B)

// Light Theme Colors
val LightBackground = Color(0xFFF6F7FC)
val LightSurface = Color(0xFFFFFFFF)
val LightSurfaceElevated = Color(0xFFF0F1FA)
val LightSurfaceVariant = Color(0xFFEBEBF7)
val LightOnBackground = Color(0xFF151329)
val LightOnSurface = Color(0xFF151329)
val LightOnSurfaceVariant = Color(0xFF514B70)
val LightOutline = Color(0xFFCAC5E3)
