package com.example.model

enum class CloneAppType {
    NATIVE_APP,
    DUAL_WEB_CONTAINER
}

enum class AppCategory {
    SOCIAL,
    GAMES,
    TOOLS,
    COMMUNICATION,
    ENTERTAINMENT,
    OTHER
}

data class ClonedApp(
    val id: String,
    val originalPackageName: String,
    val displayName: String,
    val instanceNumber: Int = 2,
    val appType: CloneAppType = CloneAppType.NATIVE_APP,
    val category: AppCategory = AppCategory.OTHER,
    val createdTimestamp: Long = System.currentTimeMillis(),
    val lastLaunchedTimestamp: Long = 0L,
    val isLocked: Boolean = false,
    val virtualDataSizeBytes: Long = 0L,
    val cacheSizeBytes: Long = 0L,
    val containerUrl: String? = null,
    val badgeColorHex: String = "#00E5FF",
    val isRunning: Boolean = false,
    val customNotes: String = ""
)
