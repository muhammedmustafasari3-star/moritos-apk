package com.example.model

import android.graphics.drawable.Drawable

data class InstalledAppInfo(
    val packageName: String,
    val appName: String,
    val versionName: String,
    val isSystemApp: Boolean,
    val category: AppCategory,
    val apkPath: String,
    val isAlreadyCloned: Boolean = false,
    val targetSdkVersion: Int = 0
)

data class DualEnginePreset(
    val id: String,
    val name: String,
    val targetUrl: String,
    val packageName: String,
    val category: AppCategory,
    val description: String,
    val primaryColorHex: String
)
