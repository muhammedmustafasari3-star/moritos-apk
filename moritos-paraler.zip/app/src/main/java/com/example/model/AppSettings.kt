package com.example.model

enum class AppThemeMode {
    SYSTEM,
    DARK,
    LIGHT
}

enum class CloningEngineMode {
    IN_CONTAINER_SANDBOX,
    MANAGED_PROFILE,
    DUAL_TASK_ISOLATION
}

data class AppSettings(
    val languageCode: String = "en", // "en", "tr", "de", "fr", "ar", "es"
    val themeMode: AppThemeMode = AppThemeMode.DARK,
    val engineMode: CloningEngineMode = CloningEngineMode.IN_CONTAINER_SANDBOX,
    val appLockEnabled: Boolean = false,
    val masterPin: String = "",
    val incognitoNotifications: Boolean = false,
    val hapticFeedback: Boolean = true
)
